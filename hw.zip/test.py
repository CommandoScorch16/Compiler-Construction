print  -input() + input()
